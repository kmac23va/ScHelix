Installation instructions

- Stop Sitecore Identity server.
- Extract content of the 'Website' folder from this archive to the root folder of Sitecore Identity server website (overwrite existing files).
- Restart Sitecore Identity server.
